
export { default as DetailedSegmentList } from './DetailedSegmentList';
export { default as SegmentDetails } from './SegmentDetails';
